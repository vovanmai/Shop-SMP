@include('templates.shopsmp.header')
@yield('main-content') 
@include('templates.shopsmp.footer')