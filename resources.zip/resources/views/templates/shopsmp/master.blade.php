@include('templates.shopsmp.header')
@yield('main-content')  
@include('templates.shopsmp.leftbar')
@include('templates.shopsmp.footer')