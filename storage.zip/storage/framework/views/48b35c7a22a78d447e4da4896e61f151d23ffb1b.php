<div class="footer">


   <div class="row">
    <div class="col-lg-12" >
        &copy;  2014 SMPShop.com | Design by: Binarytheme.com
    </div>
</div>
</div>


<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<!-- BOOTSTRAP SCRIPTS -->
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/bootstrap.min.js')); ?>"></script>
<!-- CUSTOM SCRIPTS -->
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/ckfinder/ckfinder.js')); ?>"></script>
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/bootstrap-tokenfield.min.js')); ?>"></script>
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/datatable.js')); ?>"></script>
<script src="<?php echo e(url('resources/assets/templates/admin/assets/js/script.js')); ?>"></script>
 <script src="<?php echo e(url('resources/assets/templates/admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(url('resources/assets/templates/admin/assets/js/dataTables.bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('resources/assets/templates/admin/assets/js/query.js')); ?>"></script>
<script>
      $("#mydata").dataTable();
    </script>
</body>
</html>
