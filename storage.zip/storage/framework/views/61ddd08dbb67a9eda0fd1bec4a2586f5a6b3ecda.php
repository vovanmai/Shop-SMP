<?php $__env->startSection('title'); ?>
Contact Us - SMP Shop
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>


<div class="banner-top">
	<div class="container">
		<h1>Contact</h1>
		<em></em>
		<h2><a href="<?php echo e(route('shopsmp.index.index')); ?>">Home</a><label>/</label>Contact</h2>
	</div>
</div>	

<div class="contact content">
	<div class="contact-form">
		<div class="container">
			<div class="col-md-10 contact-left">
				
						<div class=" contact-top">
							<h3>Contact with us?</h3>
							<?php if(count($errors) > 0): ?>
							<div class="row">
								<div class="col-md-12">
									<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<p class="category danger alert alert-danger"><?php echo e($error); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
							<?php endif; ?>
							<?php
								if(Auth::user()!=null){
									$fullname=Auth::user()->name;
									$email=Auth::user()->email;
									$phone=Auth::user()->phone;
								}else{
									$fullname =null;
									$phone = null;
									$email = null;
								}
								
							?>
							<form action="<?php echo e(route('shopsmp.index.contact')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

								<div>
									<span>Your Name </span>		
									<input type="text" name="contact_name" value="<?php echo e($fullname); ?>" >						
								</div>
								<div>
									<span>Your Email </span>		
									<input type="text" name="contact_email" value="<?php echo e($email); ?>" >						
								</div>
								<div>
									<span>Your Phone Number </span>		
									<input type="text" name="contact_phone" value="<?php echo e($phone); ?>" >						
								</div>
								<div>
									<span>Title</span>		
									<input type="text" name="contact_title" value="" >	
								</div>
								<div>
									<span>Your Message</span>		
									<textarea name="contact_detail"> </textarea>	
								</div>
								<label class="hvr-skew-backward">
									<input type="submit" value="Send" >
								</label>
							</form>						
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.shopsmp.homemaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>