<?php $__env->startSection('main-content'); ?>
<div class="row">
	<div class="col-lg-12">
		<h2>Brand Management</h2>   
	</div>
</div>              
<!-- /. ROW  -->
<hr />
<?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /. ROW  --> 
<div class="row text-center pad-top">
	 <div class="row col-md-12 custyle" style="margin-left:10px">
    <table class="table table-striped custab">
    <thead>
    <a href="<?php echo e(route('admin.brand.create')); ?>" class="btn btn-primary btn-xs pull-left"><b>+</b> Add new categories</a>
        <tr>
            <th class="text-center" style="width:4%">ID</th>
            <th class="text-center">Category Title</th>
            <th class="text-center">Category Desc</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
            <?php $__currentLoopData = $arCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id=$item->id;
                    $cat_name=$item->cat_name;
                    $cat_desc=$item->cat_desc;
                    $urlDel=route('admin.category.destroy',['id'=>$id]);
                    $urlEdit=route('admin.category.update',['id'=>$id]);
                ?>
            <tr>
                <td><?php echo e($id); ?></td>
                <td><?php echo e($cat_name); ?></td>
                <td><?php echo e($cat_desc); ?></td>
                <td class="text-center">
                 <a class='btn btn-success btn-xs' href=""><span class="glyphicon glyphicon-eye-open"></span> View</a> 
                <a class='btn btn-info btn-xs' href="<?php echo e($urlEdit); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
                <a class='btn btn-danger btn-xs' onclick="return confirm('Are you sure to delete ? ');"  href="<?php echo e($urlDel); ?>"><span class="glyphicon glyphicon-remove"></span> Delete</a> 
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</div>   
<div class="row">
    <div class="col-6">
           <?php echo e($arCat->links()); ?>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>