<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2 class="title">Add ThemeOption</h2>
        <a href="<?php echo e(route('admin.themeoption.index')); ?>" class="btn btn-primary btn-xs pull-left" style="display: block"><b> Back to ThemeOption</a> 
    </div>
</div>           
              <div class="row">
                    <div class="col-lg-12 col-md-12">
                            <div class="content">
                                <form action="<?php echo e(route('admin.themeoption.store')); ?>" method="post"  enctype='multipart/form-data'>
                                 <?php echo e(csrf_field()); ?>

                                 <?php if(count($errors) > 0): ?>
                                 <div class="row">
                                 <div class="col-md-12">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p class="category danger alert alert-danger"><?php echo e($error); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    </div>
                                <?php endif; ?>
                              
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Theme Title </label>
                                                <input type="text" name="title" class="form-control border-input" placeholder="" value="">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Theme Short Description</label>
                                                <textarea name="desc" rows="4" class="form-control border-input" placeholder=""></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Picture</label>
                                                <input type="file" name="picture" class="form-control border-input" placeholder="" value="">
                                            </div>
                                        </div>
                                    </div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Link </label>
                                                <input type="text" name="link" class="form-control border-input" placeholder="" value="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <input type="submit" class="btn btn-info btn-fill btn-wd" value="Add Theme" />
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>