<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2>Product Management</h2>   
    </div>
</div>              
<!-- /. ROW  -->
<hr />
<?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /. ROW  --> 
<div class="row">
    <div class="col-md-12" >
        <div style="padding-left: 15px;padding-bottom:15px;">   
            <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-info">Add Brand</a>
        </div>
    </div>
     <div class="col-md-12" >
        <div class="panel panel-default" style="margin-left:15px; margin-right:15px;">
              <div class="panel-heading text-left" ><b><i>Brand List</i></b></div>
                <div class="panel-body">
                <table class="table table-striped table-bordered table table-hover" id="mydata">
                  <thead>
                      <tr>
                          <th class="text-center">ID</th>
                          <th class="text-center">Brand Title</th>
                          <th class="text-center">Brand Desc</th>
                          <th class="text-center">Action</th>
                          
                      </tr>
                  </thead>

                  <tbody>
                       <?php $__currentLoopData = $arBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                              $id=$item->id;
                              $brand_name=$item->brand_name;
                              $brand_desc=$item->brand_desc;
                              $urlDel=route('admin.brand.destroy',['id'=>$id]);
                              $urlEdit=route('admin.brand.update',['id'=>$id]);
                          ?>
                      <tr>
                          <td><?php echo e($id); ?></td>
                          <td><?php echo e($brand_name); ?></td>
                          <td><?php echo e($brand_desc); ?></td>
                          <td class="text-center">
                          <a class='btn btn-info btn-xs' href="<?php echo e($urlEdit); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
                          <a class='btn btn-danger btn-xs' onclick="return confirm('Are you sure to delete ? ');"  href="<?php echo e($urlDel); ?>"><span class="glyphicon glyphicon-remove"></span> Delete</a> 
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   

                  </tbody>

                  <tfoot>
                    <tr></tr>
                  </tfoot>

                </table>
                </div>
            </div>  
    </div>
</div>   

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>