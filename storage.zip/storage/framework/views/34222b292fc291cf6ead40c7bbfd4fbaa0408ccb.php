<?php echo $__env->make('templates.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.admin.leftbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="content" id="app">

</div>
<div id="page-wrapper" >
<div id="page-inner">
<?php echo $__env->yieldContent('main-content'); ?>  

<!-- /. ROW  -->           
 </div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php echo $__env->make('templates.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>