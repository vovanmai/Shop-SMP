   <?php if(Session::has('msg')): ?>
   <div class="row">
   	<div class="col-lg-12 ">
   		<div class="alert alert-info">
   			<?php echo e(Session::get('msg')); ?>

   		</div>
   	</div>
   </div>
   <?php endif; ?>
   <?php if(Session::has('fixedmsg')): ?>
   <div class="row">
   	<div class="col-lg-12" style="position: fixed;top:50px">
   		<div class="alert alert-info">
   			<?php echo e(Session::get('fixedmsg')); ?>

   		</div>
   	</div>
   </div>
   <?php endif; ?>