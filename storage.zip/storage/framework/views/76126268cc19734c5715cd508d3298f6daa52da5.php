<?php if(Session::has('popupmsg')): ?>
   <script>
	smoke.alert("<?php echo e(Session::get('popupmsg')); ?>", function(e){
}, {
	ok: "OK",
	classname: "custom-class"
});
</script>
<?php endif; ?>
