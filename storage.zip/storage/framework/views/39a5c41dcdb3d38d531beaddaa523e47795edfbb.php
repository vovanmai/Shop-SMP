<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2>Product Management</h2>   
    </div>
</div>              
<!-- /. ROW  -->
<hr />
<?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('errors.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('errors.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /. ROW  --> 
<div class="row">
    <div class="col-md-12" >
        <div style="padding-left: 15px;padding-bottom:15px;">   
            <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-info">Add User</a>
        </div>
    </div>
     <div class="col-md-12" >
        <div class="panel panel-default" style="margin-left:15px; margin-right:15px;">
              <div class="panel-heading text-left" ><b><i>User List</i></b></div>
                <div class="panel-body">
                <table class="table table-striped table-bordered table table-hover" id="mydata">
                  <thead>
                      <tr>
                        <th class="text-center" style="width:4%">ID</th>
                        <th class="text-center">Username</th>
                        <th class="text-center">Fullname</th>
                        <th class="text-center" style="width:20%">Address</th>
                       
                        <th class="text-center">Phone</th>
                        <th class="text-center">Avatar</th>
                        <th class="text-center">Level (ACL)</th>
                        <th class="text-center" style="width: 200px;">Action</th>
                    </tr>
                  </thead>

                  <tbody>
                       <?php $__currentLoopData = $arUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id=$item->id;
                    $username=$item->username;
                    $name=$item->name;
                    $address=$item->address;
                  
                    $phone=$item->phone;
                    $avatar=$item->avatar;
                    $level=$item->level;
                    $urlEdit=route('admin.user.edit',['id'=>$id]);
                    $urlDel=route('admin.user.destroy',['id'=>$id]);
                    
                    if($level==1){
                        $level1="Admin";
                    }else if($level==2){
                        $level1="Moderator";
                    }else{
                        $level1="Member";
                    }

                ?>
            <tr>
                <td><?php echo e($id); ?></td>
                <td><?php echo e($username); ?></td>
                <td><?php echo e($name); ?></td>
                <td><?php echo e($address); ?></td>
               
                <td><?php echo e($phone); ?></td>
                <td>
                    <?php if($avatar!=''): ?>
                     <img style="width:100px;height:auto" src="<?php echo e(url('storage/app/avatar/'.$avatar)); ?>"/>
                    <?php else: ?>
                        No avatar image 
                    <?php endif; ?>
                </td>
                <td><?php echo e($level1); ?></td>
                <td class="text-center">
                <a class='btn btn-info btn-xs' href="<?php echo e($urlEdit); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                <?php if($username!='admin'): ?>
                <a class='btn btn-danger btn-xs' onclick="return confirm('Are you sure to delete ? ');"  href="<?php echo e($urlDel); ?>"><span class="glyphicon glyphicon-remove"></span> Delete</a> 
                <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   

                  </tbody>

                  <tfoot>
                    <tr></tr>
                  </tfoot>

                </table>
                </div>
            </div>  
    </div>
</div>   

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>