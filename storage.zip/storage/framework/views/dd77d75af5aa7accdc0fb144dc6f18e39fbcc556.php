<html>
	<head>

		<title>Lỗi truy cập</title>
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('resources/assets/templates/shopsmp/images/favicon.png')); ?>">
	</head>
	<style>
    h1{
        border: solid 1px;
        margin: 281px;
        background: red;
        width: 700px;
        padding-left: 95px;
    }
    
</style>

	<body>
		<div>	
		<a href="<?php echo e(route('auth.loginadmin')); ?>">Vui lòng Click vào đây để đăng nhập</a>
		</div>
		<h1>Bạn không có quyền truy cập vào trang này!</h1>
		

	</body>
</html>