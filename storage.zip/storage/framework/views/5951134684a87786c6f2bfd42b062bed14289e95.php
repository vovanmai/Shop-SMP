<?php $__env->startSection('main-content'); ?>

<div class="banner-top">
	<div class="container">
		<h1>Search result fors keywords: "<?php echo e($keyword); ?>"</h1>
		<em></em>
		<h2> <?php echo e($arProduct->total()); ?> matched result(s)</h2>
	</div>
</div>	
<div class="product content">
	<div class="container">
		<div class="col-md-12">
			
			<div class="mid-popular">
				<?php $__currentLoopData = $arProduct->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="row">
					<?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
							$id=$item->id;
							$pname_slug=str_slug($item->pname);
							
							$namecat_slug=str_slug($item->category->cat_name);
							$url=route('shopsmp.product.detail',['slugcat'=>$namecat_slug,'slug'=>$pname_slug,'id'=>$id]);
							$oldprice=$item->price; 
							$discount=$item->discount;
							if($discount>0){
								$newprice=((100-$discount)*$oldprice)/100;
								
							}else{
								$newprice=$item->price;
							}
						?>	
					<div class="col-md-3 item-grid1 simpleCart_shelfItem" data-id="">
						<div class=" mid-pop">
							<div class="pro-img">
								<?php if($item->discount>0): ?>
								<span class="saleicon"><?php echo e($item->discount); ?></span>
								<?php endif; ?>
								<a href="<?php echo e($url); ?>">
									<img src="<?php echo e(url('storage/app/imagefiles/'.$item->picture)); ?>" class="img-responsive" alt=""></a>
									<div class="zoom-icon ">
										<a class="picture" href="<?php echo e(url('storage/app/imagefiles/'.$item->picture)); ?>" rel="title" class="b-link-stripe b-animate-go  thickbox"><i class="glyphicon glyphicon-search icon "></i></a>
										
									</div>
								</div>
								<div class="mid-1">
									<div class="women">
										<div class="women-top">
											<span><?php echo e($item->category->cat_name); ?></span>
											<h6><a href="<?php echo e($url); ?>"><?php echo e($item->pname); ?></a></h6>
										</div>
										<div class="img item_add" id="<?php echo e($item->id); ?>>
											<a href="javascript:void(0)" onclick='alert("Add to the cart successful !");' >
												<img src="<?php echo e(url('resources/assets/templates/shopsmp/images/ca.png')); ?>" alt="">
											</a>
										</div>
										<div class="clearfix"></div>
									</div>
									<div class="mid-2">
										<p ><label><?php if($discount>0): ?>
										<?php echo e(number_format($oldprice)); ?>VNĐ <?php endif; ?></label><em class="item_price"> <?php echo e(number_format($newprice)); ?> VNĐ</em></p>
										<div class="block">
											<div class="starbox small ghosting"> </div>
										</div>

										<div class="clearfix"></div>
									</div>

								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="clearfix"></div>
	<script>
	
		$(document).ready(function(){
			$(".item_add").click(function (){
				var id=$(this).attr('id');
				$.ajax({
					url:"<?php echo e(route('shopsmp.order.cartbuying')); ?>",
					data:{'id':id},
				    type:"GET",
					success: function (data){
						$('#cart_count').html(data);
						

	     			}
	     			});
			});
		});
	</script>
					<div class="pagination">
						<?php echo e($arProduct->links()); ?>

					</div>
				
					<h2 style="color:#fff"><?php echo e($arProduct->total()); ?> result<?php if($arProduct->total()>1) echo "s"?> found for this keyword</h2>
				
				</div>
			</div>
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.shopsmp.homemaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>