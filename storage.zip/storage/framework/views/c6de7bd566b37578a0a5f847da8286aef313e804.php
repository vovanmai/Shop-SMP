   <?php if(Session::has('errormsg')): ?>
   <div class="row errormsg">
   	<div class="col-lg-12 ">
   		<div class="alert alert-danger">
   			<?php echo e(Session::get('errormsg')); ?>

   		</div>
   	</div>
   </div>
   <script type="text/javascript">
   		setTimeout(function(){
   			$('.errormsg').slideUp();
   		},3000);
   </script>
   <?php endif; ?>