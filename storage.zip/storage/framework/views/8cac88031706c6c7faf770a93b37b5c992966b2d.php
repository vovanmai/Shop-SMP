<?php $__env->startSection('title'); ?>
Login - SMP Shop
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>

<div class="banner-top">
    <div class="container">
        <h1>Login</h1>
        <em></em>
        <h2><a href="<?php echo e(route('shopsmp.index.index')); ?>">Home</a><label>/</label>Login</h2>
    </div>
</div>
<!--login-->
<div class="content">
    <div class="container">
        <div class="login">
            <?php echo $__env->make('errors.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form name="" action="<?php echo e(route('auth.login')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

            <div class="col-md-3 login-do">    
            </div>

            <div class="col-md-6 login-do">
                    <div class="row">
                     <div class="col-md-12">
                        <?php if(Session::has('msg')): ?>
                        <p class="category danger alert alert-danger"><?php echo e(Session::get('msg')); ?></p>
                        <?php endif; ?>
                    </div>
                     </div>
                     <?php if(count($errors) > 0): ?>
                    <div class="row">
                     <div class="col-md-12">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="category danger alert alert-danger"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                     </div>
                     <?php endif; ?>
                    <div class="login-mail">
                        <input name="username" type="text" placeholder="Enter Your Username/Email" required="">
                        <i  class="glyphicon glyphicon-envelope"></i>
                    </div>
                    <div class="login-mail">
                        <input type="password" name="password" placeholder="Password" required="">
                        <i class="glyphicon glyphicon-lock"></i>
                    </div>
                    <div class="guest-buy-btn">
                        <label class="hvr-skew-backward">
                            <input type="submit" value="LOGIN">
                        </label>
                    </div>
            </div>
            <div class="col-md-3 login-do">    
            </div>
            </form>
             <!--    <div class="guest-buy-btn">
                <form name="guestForm" action="" method="POST">
                     <?php echo e(csrf_field()); ?>

                        
                         
                        
                    </form>
                </div> -->
             <!--    <div class="social-btn">
                    <a href="/auth/facebook" class="btn btn-block btn-social btn-facebook">
                        <span class="fa fa-facebook"></span> Sign in with Facebook
                    </a>
                    <a href="/auth/google" class="btn btn-block btn-social btn-google">
                        <span class="fa fa-google"></span> Sign in with Google
                    </a>
                </div> -->

            
         <!--    <div class="col-md-6 login-right">
             <h3>Completely Free Account</h3>

             <p>Pellentesque neque leo, dictum sit amet accumsan non, dignissim ac mauris. Mauris rhoncus, lectus tincidunt tempus aliquam, odio 
                 libero tincidunt metus, sed euismod elit enim ut mi. Nulla porttitor et dolor sed condimentum. Praesent porttitor lorem dui, in pulvinar enim rhoncus vitae. Curabitur tincidunt, turpis ac lobortis hendrerit, ex elit vestibulum est, at faucibus erat ligula non neque.</p>
                 <a href="<?php echo e(route('auth.register')); ?>" class=" hvr-skew-backward">Register</a>

             </div> -->

             <div class="clearfix"> </div>
     </div>

 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.shopsmp.homemaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>