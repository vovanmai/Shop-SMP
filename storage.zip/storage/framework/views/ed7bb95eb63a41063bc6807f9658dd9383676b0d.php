<?php $__env->startSection('main-content'); ?>

<div class="banner-top">
	<div class="container">
		<h1>Step 1: Shipping Address</h1>
		<em></em>
		<h2><a href="<?php echo e(route('shopsmp.index.index')); ?>">Home</a><label>/</label>Shipping Address</h2>
	</div>
</div>
<div class="check-out content">
<?php if(Session::has('popupmsg')): ?>
   <script>
	smoke.alert("<?php echo e(Session::get('popupmsg')); ?>", function(e){
}, {
	ok: "OK",
	classname: "custom-class"
});
</script>
<?php endif; ?>
	<div class="container">
		<div class="row">
			<div class="col-md-6 shipping col-sm-6 col-xs-12">
				<h3 class="text-center" style="color:#E8DAB4;margin-bottom:24px;padding-bottom:25px;border-bottom:3px solid #E8DAB4">Shipping Address</h3>
				<?php if(count($errors) > 0): ?>
			
					<div class="col-md-12">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<input style="background-color:#b99f9f" type="text" name="name" class="form-control input-sm" readonly value="<?php echo e($error); ?>">
						</br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				
				<?php endif; ?>
					<?php 
				if(Auth::user()){
					$user = Auth::user();			
					$name = $user->name;
					$address = $user->address;
					$phone = $user->phone;
					$email = $user->email;
				}else{
					$name = null;
					$address = null;
					$phone = null;
					$email = null;
				}
				 ?>
				
					<div class="col-xs-6 col-sm-6 col-md-6" >
						<form action="<?php echo e(route('shopsmp.order.poststep1')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

							<div class="form-group">
								<input type="text" name="name" class="form-control input-sm" placeholder="Fullname" value="<?php echo e($name); ?>">
							</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						<div class="form-group">
							<input type="text" name="phone" class="form-control input-sm" placeholder="Phone" value="<?php echo e($phone); ?>">
						</div>
					</div>

					<div class="col-xs-6 col-sm-6 col-md-6">
						<div class="form-group">
							<input type="email" name="email" class="form-control input-sm" placeholder="Email" value="<?php echo e($email); ?>">
						</div>
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						<div class="form-group">
							<select name="payment" class="form-control border-input">
								<option value="1">Thanh toán 1</option>
								<option value="2">Thanh toán 2</option>
								<option value="3">Thanh toán 3</option>
							</select>
						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-12">
						<div class="form-group">
							<textarea placeholder="Detail" name="detail" class="form-control" rows="5"></textarea>
						</div>
					</div>

					<div class="col-xs-12 col-sm-12 col-md-12">
						<div class="form-group">
							<input type="text" class="form-control border-input" value="<?php echo e($address); ?>" name="address" placeholder="Enter shipping address">
						</div>
					</div> 
					<div class="col-md-12">
						<a href="<?php echo e(route('shopsmp.order.indexcart')); ?>" class="btn hvr-skew-backward">Back to Cart</a>
						<input  type="submit" class="btn pull-right hvr-skew-backward" value="Continue"/>
					</div>
				</div>
			</form>
			<div class="col-md-6">
				<?php if(Cart::count()>0): ?>
				<table class="table-heading simpleCart_shelfItem">
					<tr>
						<th width="20%">Item</th>
						<th width="5%">Quantity</th>
						<th>Subtotal</th>
					</tr>
					<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="cart-header">
						<td class="ring-in"><a href="" class="at-in"><img src="<?php echo e(url('storage/app/imagefiles/'.$item->options->picture)); ?>" class="img-responsive" alt=""></a>
							<div class="sed">
								<h5><a href=""><?php echo e($item->name); ?></a></h5>			
							</div>
							<div class="clearfix"> </div>
						</td>
						<td><?php echo e($item->qty); ?></td>
						<td class="item_price" style="color:#fff"><span class="subtotalprice"><?php echo e(number_format($item->price*$item->qty)); ?></span> VNĐ</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					<tr style="border-top:2px solid #E8DAB4">
						<td style="color:#fff">Total:</td>
						<td><?php echo e(Cart::count()); ?></td>
						<td><span style="color:white" class="totalprice"><?php echo e(number_format(intval(str_replace(',','',Cart::subtotal())))); ?> VNĐ</span> </td>
					</tr>
				</table>
				<?php endif; ?>
				<?php if(Cart::count()==0): ?>
					<h2 style="color:#E8DAB4;text-align: center">You dont have any item in Cart.</h2>
				<?php endif; ?>
				</br>
				<div class="four">
					<a href="<?php echo e(route('shopsmp.index.index')); ?>" class="hvr-skew-backward">Back To Shopping</a>
				</div>	
	
			</div>
		</div>
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.shopsmp.homemaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>